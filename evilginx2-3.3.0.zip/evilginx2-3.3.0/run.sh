#!/bin/bash

# Chuyển vào thư mục chứa script
cd "$(dirname "$0")"

# Chạy Evilginx2 với phishlets & redirectors
sudo ./build/evilginx -p ./phishlets -t ./redirectors -developer -debug
